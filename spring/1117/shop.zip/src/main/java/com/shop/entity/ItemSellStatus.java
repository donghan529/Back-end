package com.shop.entity;

public enum ItemSellStatus {
    SELL, SOLD_OUT
}
